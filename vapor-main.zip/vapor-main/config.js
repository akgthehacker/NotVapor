let _CONFIG = {
  wispurl: localStorage.getItem("proxServer") || "wss://anura.pro/",
  bareurl: "https://aluu.xyz/bare/",
};

// SCRAMMMMM JETTTT Configurationahahaajsasajsjsjdsjdj